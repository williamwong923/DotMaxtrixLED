import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.input.MouseEvent;

import static java.lang.Character.isLetter;

import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class StartUpWindow extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        VBox startUp = new VBox();
        startUp.setSpacing(5.5);
        startUp.setPadding(new Insets(5.5 ,5.5, 5.5, 5.5));

        Label startMessage = new Label("Enter file name to add to or create:");
        TextField fileNameField = new TextField();
        fileNameField.setPromptText("File Name");
        Button enterFile = new Button("Enter");
        startUp.getChildren().addAll(startMessage, fileNameField, enterFile);


        class enterFileEvent implements EventHandler<MouseEvent> {

            private Stage start;
            private TextField fileNameTest;

            public enterFileEvent(Stage startingStage, TextField examineField){
                start = startingStage;
                fileNameTest = examineField;
            }

            @Override
            public void handle(MouseEvent event) {
                fileTestVaild(fileNameTest.getText());
                //fileNameTest.setPromptText(fileNameTest.getText());
            }
        }


        enterFile.addEventHandler(MouseEvent.MOUSE_CLICKED, new enterFileEvent(primaryStage, fileNameField));

        Scene startScene = new Scene(startUp, 500, 150);            //Place VBox in scene
        primaryStage.setScene(startScene);
        primaryStage.setMinHeight(150);
        primaryStage.setMinWidth(250);

        primaryStage.show();


    }

    public void fileTestVaild(String fileName){
        if(fileName.length()==0 || !isLetter(fileName.charAt(0))) {
            createError("This file name is invalid. Please name files starting with a letter.");
        }
        else{
            fileStartUp(fileName);
        }
    }

    public void fileStartUp(String fileName){
        File outputCode = new File(fileName + ".txt");
        try{
            FileWriter writer = new FileWriter(outputCode, true);
            BufferedWriter toFile = new BufferedWriter(writer);
            toFile.append("Hello\n");
            toFile.flush();
            toFile.write("Worlds1");
            toFile.flush();
        }
        catch(Exception e){
            System.out.println("ERR");
        }
    }

    public void createError(String errorMessage){
        Stage errorStage = new Stage();
        VBox errorWindowStruct = new VBox();
        errorWindowStruct.setAlignment(Pos.CENTER);
        Button closeErrorWindow = new Button("Close");
        closeErrorWindow.addEventHandler(MouseEvent.MOUSE_CLICKED, new closeButton(errorStage));
        Label errorLabel = new Label(errorMessage);

        errorWindowStruct.getChildren().addAll(errorLabel, closeErrorWindow);

        Scene errorScene = new Scene(errorWindowStruct, 350, 100);
        errorStage.setScene(errorScene);
        errorStage.setTitle("ERROR");
        errorStage.show();


    }

    class browseButton implements EventHandler<MouseEvent>{
        private Stage stageClose;

        public browseButton(Stage stage){
            stageClose = stage;
        }

        @Override
        public void handle(MouseEvent event) {
            Desktop userDir = Desktop.getDesktop();
            File dirToOpen = null;
            try {
                dirToOpen = new File("c:\\folder");
                userDir.open(dirToOpen);
            } catch (Exception iae) {
                System.out.println("File Not Found");
            }
        }
    }

    class closeButton implements EventHandler<MouseEvent>{
        private Stage stageClose;

        public closeButton(Stage stage){
            stageClose = stage;
        }

        @Override
        public void handle(MouseEvent event) {
            stageClose.close();
        }
    }


}
