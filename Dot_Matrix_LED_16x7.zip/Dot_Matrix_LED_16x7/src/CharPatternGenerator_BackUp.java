
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;




public class CharPatternGenerator_BackUp extends Application {

    static int columns = 5;
    static int rows = 7;

    private Button[][] LEDMatrix;
    private Label[] PORTDout;
    private Label[] PORTBout;
    private String defaultButtonStyle = "-fx-background-radius: 10em; " +
            "-fx-min-width: 20px; " +
            "-fx-min-height: 20px; " +
            "-fx-max-width: 20px; " +
            "-fx-max-height: 20px;" +
            "-fx-border-radius: 10em; " +
            "-fx-border-color: rgb(0,0,0);" +
            "-fx-background-color: rgb(255,255,255);";
    private String pressedButtonStyle = "-fx-background-radius: 10em; " +
            "-fx-min-width: 20px; " +
            "-fx-min-height: 20px; " +
            "-fx-max-width: 20px; " +
            "-fx-max-height: 20px;" +
            "-fx-border-radius: 10em; " +
            "-fx-border-color: rgb(0,0,0);" +
            "-fx-background-color: rgb(0,0,0);";

    @Override
    public void start(Stage primaryStage) throws Exception {
        GridPane PatternGrid = new GridPane();
        PatternGrid.setHgap(11.0);
        PatternGrid.setVgap(11.0);
        PatternGrid.setAlignment(Pos.CENTER);

        //Button Initializations
        Button clear = new Button("Clear");
        Button generate = new Button("Generate");
        clear.setStyle("-fx-max-height: 15px;" );
        generate.setStyle("-fx-max-height: 15px;");

        //Label Initializations
        Label outputText = new Label("Outputs:");
        Label PORTD = new Label("PORTD");
        Label PORTB = new Label("PORTB");
        Label Col1 = new Label("Column1");
        Label Col2 = new Label("Column2");
        Label Col3 = new Label("Column3");
        Label Col4 = new Label("Column4");
        Label Col5 = new Label("Column5");

        //Textfield Initializtions
        TextField enterChar = new TextField();


        LEDMatrix = new Button[rows][columns];
        PORTDout = new Label[columns];
        PORTBout = new Label[columns];
        for(int i = 0; i<PORTDout.length; i++){
            PORTDout[i] = new Label("00000000");
            PORTBout[i] = new Label("00000000");
        }

//Event Handling
        //LED MATRIX EVENTS
        class LEDClick implements EventHandler<MouseEvent>{

            private Button target;
            private boolean pressed;
            private String pressedSyle =  pressedButtonStyle;
            private String defaultStyle = defaultButtonStyle;

            public LEDClick(Button b1){
                target = b1;
                pressed = false;
            }

            @Override
            public void handle(MouseEvent click) {
                pressed = pressed ^ true;
                if(target.getStyle().equals(defaultStyle)){
                    target.setStyle(pressedSyle);
                }
                else{
                    target.setStyle(defaultStyle);
                }
            }
        }

        //Click on Clear
        EventHandler<MouseEvent> clearClick = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                resetMatrix();
                outputGenerate();
            }
        };

        //Click on Generate
        EventHandler<MouseEvent> genClick = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                outputGenerate();
            }
        };
//OTHERS
        for(int j = 0; j<rows; j++){
            for(int i = 0; i<columns; i++){
                LEDMatrix[j][i] = new Button();
                LEDMatrix[j][i].setStyle(defaultButtonStyle);
                LEDMatrix[j][i].addEventHandler(MouseEvent.MOUSE_CLICKED, new LEDClick(LEDMatrix[j][i]));
                PatternGrid.add(LEDMatrix[j][i], i, j);
            }
        }

        clear.addEventHandler(MouseEvent.MOUSE_CLICKED, clearClick);
        generate.addEventHandler(MouseEvent.MOUSE_CLICKED, genClick);
        PatternGrid.add(clear, 6, 3);
        PatternGrid.add(generate, 6, 4);
        PatternGrid.add(outputText, 8, 0);
        PatternGrid.add(PORTD, 7, 2);
        PatternGrid.add(PORTB, 7, 3);
        PatternGrid.add(Col1, 8, 1);
        PatternGrid.add(Col2, 9, 1);
        PatternGrid.add(Col3, 10, 1);
        PatternGrid.add(Col4, 11, 1);
        PatternGrid.add(Col5, 12, 1);
        for(int i = 0; i< PORTDout.length; i++){
            PatternGrid.add(PORTDout[i], 8+i, 2);
            PatternGrid.add(PORTBout[i], 8+i, 3);
        }


        Scene scene = new Scene(PatternGrid, 500, 250);            //Place VBox in scene
        primaryStage.setTitle("Character Generator");                       //Name title
        primaryStage.setScene(scene); // Place the scene in the stage  //Place Scene in stage
        primaryStage.setMinWidth(625);                                 //Set minimum width of Window
        primaryStage.setMinHeight(300);                                //Set minimum height of window
        primaryStage.show(); // Display the stage                      //show window

    }

    public void resetMatrix() {
        for (int j = 0; j < rows; j++) {
            for (int i = 0; i < columns; i++) {
                LEDMatrix[j][i].setStyle(
                        "-fx-background-radius: 10em; " +
                                "-fx-min-width: 20px; " +
                                "-fx-min-height: 20px; " +
                                "-fx-max-width: 20px; " +
                                "-fx-max-height: 20px;" +
                                "-fx-border-radius: 10em; " +
                                "-fx-border-color: rgb(0,0,0);" +
                                "-fx-background-color: rgb(255,255,255);"
                );
            }

        }
    }

    public void outputGenerate(){
        String Doutput = "00";
        String Boutput = "0000000";
        for(int col = 0; col<columns; col++){
            Doutput = "00";
            Boutput = "0000000";
            for(int row = 0; row<rows-1; row++){
                //If the LED button is pressed, add a '1' to the text
                if(LEDMatrix[row][col].getStyle().equals(pressedButtonStyle)){
                    Doutput = "1" + Doutput;
                }
                else{
                    Doutput = "0" + Doutput;
                }
            }
            if(LEDMatrix[6][col].getStyle().equals(pressedButtonStyle)){
                Boutput = Boutput + "1";
            }
            else{
                Boutput = Boutput + "0";
            }
            PORTDout[col].setText(Doutput);
            PORTBout[col].setText(Boutput);
        }

    }

    public static void main(String[] args){

        launch(args);

    }
}

