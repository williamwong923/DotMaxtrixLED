import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

public class FileTesting {
    public static void main(String [] args){
        File outputCode = new File("test1.txt");
        try{
            FileWriter writer = new FileWriter(outputCode, true);
            BufferedWriter tofile = new BufferedWriter(writer);
            tofile.append("Hello\n");
            tofile.append("Worlds");
            tofile.flush();
            tofile.write("Worlds1");
            tofile.flush();
        }
        catch(Exception e){
            System.out.println("ERR");
        }


    }


}
