import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import static java.lang.Character.isLetter;

public class CharPatternGenerator extends Application {

    static int columns = 5;
    static int rows = 7;

    private Button[][] LEDMatrix;
    private Label[] PORTDout;
    private Label[] PORTBout;
    private String defaultButtonStyle = "-fx-background-radius: 10em; " +
            "-fx-min-width: 20px; " +
            "-fx-min-height: 20px; " +
            "-fx-max-width: 20px; " +
            "-fx-max-height: 20px;" +
            "-fx-border-radius: 10em; " +
            "-fx-border-color: rgb(0,0,0);" +
            "-fx-background-color: rgb(255,255,255);";
    private String pressedButtonStyle = "-fx-background-radius: 10em; " +
            "-fx-min-width: 20px; " +
            "-fx-min-height: 20px; " +
            "-fx-max-width: 20px; " +
            "-fx-max-height: 20px;" +
            "-fx-border-radius: 10em; " +
            "-fx-border-color: rgb(0,0,0);" +
            "-fx-background-color: rgb(0,0,0);";

    @Override
    public void start(Stage primaryStage) throws Exception {
        VBox startUp = new VBox();
        startUp.setSpacing(5.5);
        startUp.setPadding(new Insets(5.5 ,5.5, 5.5, 5.5));

        Label startMessage = new Label("Enter file name to add to or create:");
        TextField fileNameField = new TextField();
        fileNameField.setPromptText("File Name");
        Button enterFile = new Button("Enter");
        startUp.getChildren().addAll(startMessage, fileNameField, enterFile);


        enterFile.addEventHandler(MouseEvent.MOUSE_CLICKED, new enterFileEvent(primaryStage, fileNameField));

        Scene startScene = new Scene(startUp, 500, 150);            //Place VBox in scene
        primaryStage.setScene(startScene);
        primaryStage.setMinHeight(150);
        primaryStage.setMinWidth(250);

        primaryStage.show();


    }

    public void resetMatrix() {
        for (int j = 0; j < rows; j++) {
            for (int i = 0; i < columns; i++) {
                LEDMatrix[j][i].setStyle(
                                "-fx-background-radius: 10em; " +
                                "-fx-min-width: 20px; " +
                                "-fx-min-height: 20px; " +
                                "-fx-max-width: 20px; " +
                                "-fx-max-height: 20px;" +
                                "-fx-border-radius: 10em; " +
                                "-fx-border-color: rgb(0,0,0);" +
                                "-fx-background-color: rgb(255,255,255);"
                );
            }

        }
    }


    public void generator(String fileName) {
        Stage driverStage = new Stage();

        VBox mainGUIStruct = new VBox();

        GridPane PatternGrid = new GridPane();
        PatternGrid.setHgap(11.0);
        PatternGrid.setVgap(11.0);
        PatternGrid.setAlignment(Pos.CENTER);

        //Button Initializations
        Button clear = new Button("Clear");
        Button generate = new Button("Generate");
        clear.setStyle("-fx-max-height: 15px;");
        generate.setStyle("-fx-max-height: 15px;");

        //Label Initializations
        Label outputText = new Label("Outputs:");
        Label PORTD = new Label("PORTD");
        Label PORTB = new Label("PORTB");
        Label Col1 = new Label("Column1");
        Label Col2 = new Label("Column2");
        Label Col3 = new Label("Column3");
        Label Col4 = new Label("Column4");
        Label Col5 = new Label("Column5");

        Label enterCharLaabel = new Label("Enter character to generate: ");

        //Textfield Initializtions
        HBox charInfoContain = new HBox();
        charInfoContain.setAlignment(Pos.BOTTOM_CENTER);
        TextField enterChar = new TextField();
        enterChar.setMaxWidth(30);

        charInfoContain.getChildren().addAll(enterCharLaabel, enterChar);

        LEDMatrix = new Button[rows][columns];
        PORTDout = new Label[columns];
        PORTBout = new Label[columns];
        for (int i = 0; i < PORTDout.length; i++) {
            PORTDout[i] = new Label("00000000");
            PORTBout[i] = new Label("00000000");
        }
//This portion of code handles file set ups
        File outputCode = new File(fileName + ".txt");
        try {
            FileWriter writer = new FileWriter(outputCode, true);
            BufferedWriter toFile = new BufferedWriter(writer);

            //Event Handling
            //LED MATRIX EVENTS
            class LEDClick implements EventHandler<MouseEvent>{

                private Button target;
                private boolean pressed;
                private String pressedSyle =  pressedButtonStyle;
                private String defaultStyle = defaultButtonStyle;

                public LEDClick(Button b1){
                    target = b1;
                    pressed = false;
                }

                @Override
                public void handle(MouseEvent click) {
                    pressed = pressed ^ true;
                    if(target.getStyle().equals(defaultStyle)){
                        target.setStyle(pressedSyle);
                    }
                    else{
                        target.setStyle(defaultStyle);
                    }
                }
            }

            //Click on Clear
            EventHandler<MouseEvent> clearClick = new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    resetMatrix();
                    outputGenerate();
                }
            };

            //Click on Generate
            class genClick implements EventHandler<MouseEvent>{
                private BufferedWriter toFileOut;
                private TextField genChar;

                public genClick(BufferedWriter inputBuffWr, TextField inputStr){
                    toFileOut = inputBuffWr;
                    genChar = inputStr;
                }
                @Override
                public void handle(MouseEvent event) {
                    String[] DB = outputGenerateDB();
                    writeToFile(toFileOut, DB[0], DB[1], genChar.getText());
                }
            }

//Formatting and adding buttons to their places in the PatternGrid
            for(int j = 0; j<rows; j++){
                for(int i = 0; i<columns; i++){
                    LEDMatrix[j][i] = new Button();
                    LEDMatrix[j][i].setStyle(defaultButtonStyle);
                    LEDMatrix[j][i].addEventHandler(MouseEvent.MOUSE_CLICKED, new LEDClick(LEDMatrix[j][i]));
                    PatternGrid.add(LEDMatrix[j][i], i, j);
                }
            }

            //Adding event handlers to other modules
            enterChar.addEventHandler(KeyEvent.KEY_TYPED, new typeLengthMax(enterChar));
            clear.addEventHandler(MouseEvent.MOUSE_CLICKED, clearClick);
            generate.addEventHandler(MouseEvent.MOUSE_CLICKED, new genClick(toFile, enterChar));

            //Adding labels representing output code to the Pattern Grid
            PatternGrid.add(clear, 6, 3);
            PatternGrid.add(generate, 6, 4);
            PatternGrid.add(outputText, 8, 0);
            PatternGrid.add(PORTD, 7, 2);
            PatternGrid.add(PORTB, 7, 3);
            PatternGrid.add(Col1, 8, 1);
            PatternGrid.add(Col2, 9, 1);
            PatternGrid.add(Col3, 10, 1);
            PatternGrid.add(Col4, 11, 1);
            PatternGrid.add(Col5, 12, 1);

            for(int i = 0; i< PORTDout.length; i++){
                PatternGrid.add(PORTDout[i], 8+i, 2);
                PatternGrid.add(PORTBout[i], 8+i, 3);
            }

            //Final formatting for the window to be displayed
            mainGUIStruct.getChildren().addAll(charInfoContain, PatternGrid);
            Scene scene = new Scene(mainGUIStruct, 500, 250);            //Place VBox in scene
            driverStage.setTitle("Character Generator");                       //Name title
            driverStage.setScene(scene); // Place the scene in the stage  //Place Scene in stage
            driverStage.setMinWidth(625);                                 //Set minimum width of Window
            driverStage.setMinHeight(300);                                //Set minimum height of window
            driverStage.show(); // Display the stage                      //show window

    } catch (Exception e) {
            System.out.println("ERR");
        }
    }
    public static void main(String[] args){
        launch(args);
    }

//Character code generator
    public void outputGenerate(){
        String Doutput = "00";
        String Boutput = "0000000";
        for(int col = 0; col<columns; col++){
            Doutput = "00";
            Boutput = "0000000";
            for(int row = 0; row<rows-1; row++){
                //If the LED button is pressed, add a '1' to the text
                if(LEDMatrix[row][col].getStyle().equals(pressedButtonStyle)){
                    Doutput = "1" + Doutput;
                }
                else{
                    Doutput = "0" + Doutput;
                }
            }
            if(LEDMatrix[6][col].getStyle().equals(pressedButtonStyle)){
                Boutput = Boutput + "1";
            }
            else{
                Boutput = Boutput + "0";
            }
            PORTDout[col].setText(Doutput);
            PORTBout[col].setText(Boutput);
        }
    }

    /*Function: outputGenerateDB()

     *Description: This function generates an array of exactly 2 strings. The first element represents the character
     *  codes used for PORTD. The first element represents the character codes used for PORTB. The format of the string
     *  is as follows: {#, #, #, #, #}; where each '#' represents a string of a combination of eight 0's or 1's. There
     *  are exactly 5 such combinations that are used to represent the output necessary to output the correct character.
     *  These outputs are also displayed in the GUI, under the "Outputs" label as well as their corresponding "Column"
     *  label
     *
     *Returns: String []
     *
     */
    public String [] outputGenerateDB(){
        String arrayD = "{";    //Each of these strings start off with a "{", which in arduino will signify the start of
        String arrayB = "{";    //an array.
        String Doutput = "00";  //For each PORTD string output, 00 will be the LSB since they shall not be used by the
                                //  MCU for the purposes of representing the character.
        String Boutput = "0000000"; //For each PORTD string output, 0000000 will be the MSB since they shall not be
                                    // used by the MCU for the purposes of representing the character.
        for(int col = 0; col<columns; col++){
            Doutput = "00";
            Boutput = "0010000";
            for(int row = 0; row<rows-1; row++){
                //If the LED button is pressed, add a '1' to the start of the PORTD representation, otherwise add a '0'
                if(LEDMatrix[row][col].getStyle().equals(pressedButtonStyle)){
                    Doutput = "1" + Doutput;
                }
                else{
                    Doutput = "0" + Doutput;
                }
            }
            //Because the final column needs to be represented as the LSB of PORTB, this is done only once at the end of
            //  the column.
            if(LEDMatrix[6][col].getStyle().equals(pressedButtonStyle)){
                Boutput = Boutput + "1";
            }
            else{
                Boutput = Boutput + "0";
            }

            //Update the GUI outputs to reflect the change in character design
            PORTDout[col].setText(Doutput);
            PORTBout[col].setText(Boutput);

            //This section adds the generated column code to the final code representation to be output to a file
            if(col!=columns-1){
                arrayD = arrayD  + "B" + Doutput + ", ";
                arrayB = arrayB  + "B" + Boutput + ", ";
            }
            else{
                arrayD = arrayD  + "B" + Doutput + "};";
                arrayB = arrayB  + "B" + Boutput + "};";
            }


        }
        String [] DB = {arrayD, arrayB};
        return DB;
    }

//Test function for validity of filenames
    public void fileTestVaild(String fileName, Stage closeIfValid){

        /* File validity is tested by observing the first character; If it is not a letter or there is no first
        *    character it is not valid, and the user will be prompted to enter another file name. If it is valid, then
        *    function generator is called and the current window is automatically closed.
        *
         */
        if(fileName.length()==0 || !isLetter(fileName.charAt(0))) {
            createError("This file name is invalid. Please name files starting with a letter.");
        }
        else{
            generator(fileName);
            closeIfValid.close();
        }
    }

//write to File
    public void writeToFile(BufferedWriter toFileOutput, String codePORTD, String codePORTB, String character){
        try{
            /*The final text to be output to the file is as follows:
             *      /* <char> code * /
             *      const byte <char>_PORTD[] {#, #, #, #, #};
             *      const byte <char>_PORTB[] {#, #, #, #, #};
             *
             *  where each "{#, #, #, #, #};" is the string output by the function outputGenerateDB
             */
            toFileOutput.append("/* " + character + " code */\n");
            toFileOutput.append("const byte " + character + "_PORTD[] " + codePORTD + "\n");
            toFileOutput.append("const byte " + character + "_PORTB[] " + codePORTB + "\n");
            toFileOutput.append("\n");
            toFileOutput.flush();
        }
        catch(Exception e){
            System.out.println("ERR");
        }
    }

    /* Class: closeButton
     * Description: this class handles a Mouse event that closes the targeted Stage
     *
     */
    class closeButton implements EventHandler<MouseEvent>{

        private Stage stageClose;           //the targeted stage

        public closeButton(Stage stage){
            stageClose = stage;
        }

        @Override
        public void handle(MouseEvent event) {
            stageClose.close();
        }
    }

    /* Class: enterFileEvent
     * Description: this class handles a Mouse event that calls the function fileTestValid
     *
     */
    class enterFileEvent implements EventHandler<MouseEvent> {

        private Stage start;                //the targeted stage
        private TextField fileNameTest;     //The textField

        public enterFileEvent(Stage startingStage, TextField examineField){
            start = startingStage;
            fileNameTest = examineField;
        }

        @Override
        public void handle(MouseEvent event) {
            fileTestVaild(fileNameTest.getText(), start);
        }
    }
//Create an error message box
    public void createError(String errorMessage){
        Stage errorStage = new Stage();
        VBox errorWindowStruct = new VBox();
        errorWindowStruct.setAlignment(Pos.CENTER);
        Button closeErrorWindow = new Button("Close");
        closeErrorWindow.addEventHandler(MouseEvent.MOUSE_CLICKED, new closeButton(errorStage));
        Label errorLabel = new Label(errorMessage);

        errorWindowStruct.getChildren().addAll(errorLabel, closeErrorWindow);

        Scene errorScene = new Scene(errorWindowStruct, 350, 100);
        errorStage.setScene(errorScene);
        errorStage.setTitle("ERROR");
        errorStage.show();

    }
/* Class: typeLengthMax
 * Description: this class handles a key event that forces only a single character to be written into a TextField
 *
 */
    class typeLengthMax implements EventHandler<KeyEvent> {

        private TextField name;         //the targeted TextField

        typeLengthMax (TextField t){
            name = t;
        }
        @Override
        public void handle(KeyEvent keyEvent) {
            if(name.getText().length() >= 1){
                name.setText(name.getText(0, 0));
                name.positionCaret(1);
            }
        }
    }
}

