import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.event.EventHandler;

public class DataEntryGUI extends Application {

    //TextField, Button, and popUp Variables
    public TextField name1;
    public TextField name2;
    public TextField name3;
    public TextField num1;
    public TextField num2;
    public TextField num3;
    public Button confirm;
    public Stage popUp;
    @Override
    public void start(Stage primaryStage) {
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setHgap(5.5);
        pane.setVgap(5.5);
        pane.setPadding(new Insets(5, 5, 5, 5));

// Place nodes in the pane
        name1 = createNewNameField();
        name2 = createNewNameField();
        name3 = createNewNameField();
        num1 =  createNewNumberField();
        num2 =  createNewNumberField();
        num3 =  createNewNumberField();

        pane.add(name1, 0, 0);
        pane.add(name2, 0, 1);
        pane.add(name3, 0, 2);
        pane.add(num1, 1, 0);
        pane.add(num2, 1, 1);
        pane.add(num3, 1, 2);
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(5,5,5,5));

//Buttons
        confirm = new Button("Create Profiles");
        confirm.setMinWidth(100.0);
        confirm.setDisable(true);

//Event Handling
        // Text
        class textFocusListener implements ChangeListener<Boolean>{
            //TextField to hold for operations
            private TextField target;

            //Constructor to hold TextField
            public textFocusListener(TextField t1){
                target = t1;
            }

            //Event actions:
            //  1) When in focus and the font color is rgb(150 150, 150), the text field is cleared and font becomes
            //      black
            //  2) When in focus for other situations the font color is set to black
            //  3) When out of focus the function checkNameInfo() is called to determine the validity of the entered
            //      text
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean aBoolean, Boolean newPropertyVal) {
                if(newPropertyVal && target.getStyle().equals("-fx-text-inner-color: rgb(150, 150, 150)")){
                    target.setText("");
                    target.setStyle("-fx-text-inner-color: rgb(0, 0, 0)");
                    target.requestFocus();
                }
                else if(newPropertyVal){
                    target.setStyle("-fx-text-inner-color: rgb(0, 0, 0)");
                    target.requestFocus();
                }
                else{
                    checkNameInfo(target);
                    updateButtonStatus();
                }
            }
        }

        class textNumFocusListener implements ChangeListener<Boolean>{
            //TextField saved
            private TextField target;


            public textNumFocusListener(TextField t1){
                target = t1;
            }

            //Event actions:
            //  1) When in focus and the font color is rgb(150 150, 150), the text field is cleared and font becomes
            //      black
            //  2) When in focus for other situations the font color is set to black
            //  3) When out of focus the function checkNameInfo() is called to determine the validity of the entered
            //      text
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean aBoolean, Boolean newPropertyVal) {
                if(newPropertyVal && target.getStyle().equals("-fx-text-inner-color: rgb(150, 150, 150)")){
                    target.setText("");
                    target.setStyle("-fx-text-inner-color: rgb(0, 0, 0)");
                    target.requestFocus();
                }
                else if(newPropertyVal){
                    target.setStyle("-fx-text-inner-color: rgb(0, 0, 0)");
                    target.requestFocus();
                }
                else{
                    checkNumInfo(target);
                    updateButtonStatus();
                }
            }
        }

        //This event handler triggers upon a KeyEvent, preferably a KEY_TYPED event. It checks the number of characters
        //  typed in the current TextField and will not allow the user to type more than 20 characters.
        class typeLengthMax implements EventHandler<KeyEvent> {
            private TextField name;
            typeLengthMax (TextField t){
                name = t;
            }
            @Override
            public void handle(KeyEvent keyEvent) {
                if(name.getText().length() >= 20){
                    name.setText(name.getText(0, 19));
                    name.positionCaret(19);
                }
            }
        }

        //This event handler triggers upon a KeyEvent, preferably a KEY_TYPED event. It checks the number of characters
        //  typed in the current TextField and will not allow the user to type more than 13 characters.
        class typeLengthMaxNum implements EventHandler<KeyEvent> {
            private TextField name;
            typeLengthMaxNum (TextField t){
                name = t;
            }
            @Override
            public void handle(KeyEvent keyEvent) {
                if(name.getText().length() >= 14){
                    name.setText(name.getText(0, 13));
                    name.positionCaret(13);
                }
            }
        }

        //Adding a focus Listener to all TextFields. This is used to indicate if the user is currently on some TextField
        name1.focusedProperty().addListener(new textFocusListener(name1));
        name2.focusedProperty().addListener(new textFocusListener(name2));
        name3.focusedProperty().addListener(new textFocusListener(name3));
        num1.focusedProperty().addListener(new textNumFocusListener(num1));
        num2.focusedProperty().addListener(new textNumFocusListener(num2));
        num3.focusedProperty().addListener(new textNumFocusListener(num3));

        //Handlers added for KEY_TYTPED KeyEvents are added to each TextField to constantly check for character length
        //  checks.
        name1.addEventHandler(KeyEvent.KEY_TYPED, new typeLengthMax(name1));
        name2.addEventHandler(KeyEvent.KEY_TYPED, new typeLengthMax(name2));
        name3.addEventHandler(KeyEvent.KEY_TYPED, new typeLengthMax(name3));
        num1.addEventHandler(KeyEvent.KEY_TYPED, new typeLengthMaxNum(num1));
        num2.addEventHandler(KeyEvent.KEY_TYPED, new typeLengthMaxNum(num2));
        num3.addEventHandler(KeyEvent.KEY_TYPED, new typeLengthMaxNum(num3));

//Button
        //The EventHandler for the "confirm" button. When clicked, the button will open up a pop-up window indicating if
        //  profile creation was successful or failed. Upon a successful profile creation, all TextFields and the button
        //  itself will become disabled.
        EventHandler<MouseEvent> buttonClick = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                popUp = new Stage();                //Create a new stage
                popUp.initOwner(primaryStage);
                VBox messageWin = new VBox();       //create a new VBox to place button and label
                Button close = new Button();        //create button  with no text
                Label message = new Label();        //create Label with no text
                close.setText("Close");             //Name the button "close"

                //If the button is pressed, close the stage
                EventHandler<MouseEvent> closeWindow = event -> popUp.close();
                close.addEventHandler(MouseEvent.MOUSE_CLICKED, closeWindow);

                //If the TextFields are all valid then disable them and the Button then have the text and title read a
                //  successful outcome
                if(checkValidText(name1, name2, name3, num1, num2, num3) == 1){
                    message.setText("The profiles have been saved and added to the database");
                    popUp.setTitle("Profile Created");
                    name1.setDisable(true);
                    name2.setDisable(true);
                    name3.setDisable(true);
                    num1.setDisable(true);
                    num2.setDisable(true);
                    num3.setDisable(true);
                    confirm.setDisable(true);
                }
                //If the TextFields are all invalid then disable them and the Button then have the text and title read a
                //  failed outcome
                else if(checkValidText(name1, name2, name3, num1, num2, num3) == 0){
                    message.setText("Invalid input: you have attempted to provide one or more invalid\n" +
                            "input(s). Please correct the information displayed in red and retry.");

                    popUp.setTitle("ERROR");
                }
                messageWin.setAlignment(Pos.CENTER);                        //align to center
                messageWin.getChildren().addAll(message, close);            //add button and Label
                Scene popScene = new Scene(messageWin, 400, 100);    //Create scene with VBox
                popUp.setScene(popScene);                                   //place scene in stage

                primaryStage.close();

                popUp.show();                                               //show stage
            }
        };

        confirm.addEventHandler(MouseEvent.MOUSE_CLICKED, buttonClick); //Add event handler to the button
        VBox rootPane = new VBox();                                     //Create VBox to contain grid pane and button
        rootPane.getChildren().addAll(pane, confirm);                   //place grid pane and button in VBx
        rootPane.setAlignment(Pos.CENTER);                              //Align to center
        rootPane.setPadding(new Insets(5, 5, 5, 5));
// Create a scene and place it in the stage
        Scene scene = new Scene(rootPane, 500, 250);            //Place VBox in scene
        primaryStage.setTitle("Data Entry GUI");                       //Name title
        primaryStage.setScene(scene); // Place the scene in the stage  //Place Scene in stage
        primaryStage.setMinWidth(325);                                 //Set minimum width of Window
        primaryStage.setMinHeight(200);                                //Set minimum height of window
        primaryStage.show(); // Display the stage                      //show window



    }

    public static void main(String[] args){


        launch(args);


    }

    /* method: createNewNameField
     *  description: Instantiates a new TextField formatted such that the text description reads "Name" and the color
     *       is rgb(150, 150,150)
     *  Returns: TextField - formatted
     *
     */
    public TextField createNewNameField(){
        TextField name = new TextField();
        name.setText("Name");
        name.setStyle("-fx-text-inner-color: rgb(150, 150, 150)");
        return name;
    }

    /* method: createNewNameField
     *  description: Instantiates a new TextField formatted such that the text description reads "(###) ###-####"
     *      and the color is rgb(150, 150,150).
     *  Returns: TextField - formatted
     *
     */
    public TextField createNewNumberField(){
        TextField number = new TextField();
        number.setText("(###) ###-####");
        number.setStyle("-fx-text-inner-color: rgb(150, 150, 150)");
        return number;
    }

    /*  Method: checkNameInfo
     *  Description: For a TextField passed into the function, the TextField is checked for correct formatting. If the
     *      TextField is empty, then it returns the default format. If the formatting is incorrect, then the contents
     *      of the TextField change to a red color. If the formatting is correct, then the contents remain as is.
     *  Parameter: TextField t1
     *
     */
    public void checkNameInfo(TextField t1){
        if(t1.getText().isEmpty()){
            t1.setText("Name");
            t1.setStyle("-fx-text-inner-color: rgb(150, 150, 150)");
        }
        else{
            String[] names = t1.getText().split(" ");
            if(names.length != 2){
                t1.setStyle("-fx-text-inner-color:red");
            }
            else if (('A' <= names[0].charAt(0) && names[0].charAt(0) <= 'Z')&&
                    ('A' <= names[1].charAt(0) && names[1].charAt(0) <= 'Z')&&
                    (names[0].substring(1).toLowerCase().equals(names[0].substring(1))&&names[1].substring(1).toLowerCase().equals(names[1].substring(1)))&&
                    (names[0].matches("^[a-zA-Z]*$")&&names[1].matches("^[a-zA-Z]*$"))&&
                    (names.length == 2)){
                t1.setStyle("-fx-text-inner-color: rgb(0, 0, 0)");
            }
            else{t1.setStyle("-fx-text-inner-color:red");
            }
        }
    }
    /*  Method: checkNumInfo
     *  Description: For a TextField passed into the function, the TextField is checked for correct formatting. If the
     *      TextField is empty, then it returns the default format. If the formatting is incorrect, then the contents
     *      of the TextField change to a red color. If the formatting is correct, then the contents remain as is.
     *  Parameter: TextField t1
     *
     */
    public void checkNumInfo(TextField t1){
        if(t1.getText().isEmpty()){
            t1.setText("(###) ###-####");
            t1.setStyle("-fx-text-inner-color: rgb(150, 150, 150)");
        }
        else{
            if(numberFormatCorrect(t1.getText())){ t1.setStyle("-fx-text-inner-color: rgb(0, 0, 0)");
            }
            else{ t1.setStyle("-fx-text-inner-color:red");
            }
        }
    }
    /*  Method: checkValidText
     *  Description: For all TextFields passed into this function, their validity is checked. If any one of the fields
     *      is greyed out (color = rgb(150, 150, 150)) then a -1 is returned. If any one of the fields is red,
     *      indicating an invalid field, then a 0 is returned. Otherwise, TextField text color is black, indicating that
     *      the text has valid formatting, and a 1 is returned.
     *  Parameter: TextField t1, TextField t2, TextField t3, TextField t4, TextField t5, TextField t6
     *  Returns: int
     *
     */
    public int checkValidText(TextField t1, TextField t2,TextField t3,TextField t4,TextField t5,TextField t6){
        if((t1.getStyle().equals("-fx-text-inner-color: rgb(150, 150, 150)"))||
                (t2.getStyle().equals("-fx-text-inner-color: rgb(150, 150, 150)"))||
                (t3.getStyle().equals("-fx-text-inner-color: rgb(150, 150, 150)"))||
                (t4.getStyle().equals("-fx-text-inner-color: rgb(150, 150, 150)"))||
                (t5.getStyle().equals("-fx-text-inner-color: rgb(150, 150, 150)"))||
                (t6.getStyle().equals("-fx-text-inner-color: rgb(150, 150, 150)"))){
            return -1;
        }
        else if((t1.getStyle().equals("-fx-text-inner-color:red"))||
                (t2.getStyle().equals("-fx-text-inner-color:red"))||
                (t3.getStyle().equals("-fx-text-inner-color:red"))||
                (t4.getStyle().equals("-fx-text-inner-color:red"))||
                (t5.getStyle().equals("-fx-text-inner-color:red"))||
                (t6.getStyle().equals("-fx-text-inner-color:red"))){
            return 0;
        }
        else return 1;
    }

    /*  Method: numberFormatCorrect
     *  Description: For some string passed into this function, that string is tested for correct formatting. A
     *      correctly formatted number is defined as the following:
     *          1) number is EXACTLY 14 characters long
     *          2) number is formatted strictly as so: (###) ###-#### where each '#' represents an ASCII representation
     *                  of a digit character from '0' to '9'. The '(', ')' and '-' characters as well as the whitepace
     *                 must be included for a correct format.
     *  Parameter: String number
     *  Returns: Boolean
     *
     */
    public boolean numberFormatCorrect(String number){
        if(number.length()!=14){
            return false;
        }
        if(number.charAt(0) != '(' || number.charAt(4) != ')'){
            return false;
        }
        else if(!(number.substring(1,3).matches("^[0-9]*$") &&
                number.substring(6,8).matches("^[0-9]*$") &&
                number.substring(10,13).matches("^[0-9]*$"))){
            return false;
        }
        else if(number.charAt(9) != '-'){
            return false;
        }
        else{
            return true;
        }
    }

    /*  Method: updateButtonStatus
     *  Description: checks all textFields. If none of them are empty, even if incorrectly formatted, then the Button
     *      "confirm1' is enabled.
     *
     */
    public void updateButtonStatus(){
        if(checkValidText(this.name1, this.name2, this.name3, this.num1, this.num2, this.num3)==-1){
            this.confirm.setDisable(true);
        }
        else {
            this.confirm.setDisable(false);
        }
    }
}